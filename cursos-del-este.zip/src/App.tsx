import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  BookOpen, 
  GraduationCap, 
  Users, 
  Clock, 
  ChevronRight, 
  Star, 
  Search, 
  Menu, 
  X, 
  Facebook, 
  Instagram, 
  Twitter,
  Mail,
  Phone,
  MapPin,
  CheckCircle2,
  ArrowRight
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";

const CATEGORIES = [
  { id: 1, name: "Informática", icon: BookOpen, count: 12 },
  { id: 2, name: "Idiomas", icon: GraduationCap, count: 8 },
  { id: 3, name: "Administración", icon: Users, count: 15 },
  { id: 4, name: "Oficios", icon: Clock, count: 20 },
];

const COURSES = [
  {
    id: 1,
    title: "Excel Avanzado para Negocios",
    category: "Informática",
    price: "$4500",
    duration: "4 semanas",
    rating: 4.8,
    image: "https://picsum.photos/seed/excel/800/600",
    featured: true
  },
  {
    id: 2,
    title: "Inglés para Viajeros",
    category: "Idiomas",
    price: "$3800",
    duration: "6 semanas",
    rating: 4.9,
    image: "https://picsum.photos/seed/english/800/600",
    featured: true
  },
  {
    id: 3,
    title: "Secretariado Ejecutivo",
    category: "Administración",
    price: "$5200",
    duration: "8 semanas",
    rating: 4.7,
    image: "https://picsum.photos/seed/admin/800/600",
    featured: true
  },
  {
    id: 4,
    title: "Reparación de PC",
    category: "Oficios",
    price: "$4000",
    duration: "5 semanas",
    rating: 4.6,
    image: "https://picsum.photos/seed/pc/800/600",
    featured: false
  },
  {
    id: 5,
    title: "Marketing Digital",
    category: "Administración",
    price: "$4800",
    duration: "4 semanas",
    rating: 4.9,
    image: "https://picsum.photos/seed/marketing/800/600",
    featured: false
  },
  {
    id: 6,
    title: "Diseño Gráfico",
    category: "Informática",
    price: "$5500",
    duration: "10 semanas",
    rating: 4.8,
    image: "https://picsum.photos/seed/design/800/600",
    featured: false
  }
];

export default function App() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
      {/* Navbar */}
      <nav className={`fixed top-0 z-50 w-full transition-all duration-300 ${isScrolled ? "bg-white/80 backdrop-blur-md shadow-sm py-3" : "bg-transparent py-5"}`}>
        <div className="container mx-auto px-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-blue-600 p-2 rounded-lg">
              <GraduationCap className="text-white w-6 h-6" />
            </div>
            <span className="text-xl font-bold tracking-tight text-blue-900">Cursos del Este</span>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            <a href="#" className="text-sm font-medium hover:text-blue-600 transition-colors">Inicio</a>
            <a href="#cursos" className="text-sm font-medium hover:text-blue-600 transition-colors">Cursos</a>
            <a href="#nosotros" className="text-sm font-medium hover:text-blue-600 transition-colors">Nosotros</a>
            <a href="#contacto" className="text-sm font-medium hover:text-blue-600 transition-colors">Contacto</a>
            <Button variant="default" className="bg-blue-600 hover:bg-blue-700">Inscribirse</Button>
          </div>

          {/* Mobile Nav */}
          <div className="md:hidden">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Menu className="w-6 h-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[400px]">
                <div className="flex flex-col gap-6 mt-10">
                  <a href="#" className="text-lg font-semibold">Inicio</a>
                  <a href="#cursos" className="text-lg font-semibold">Cursos</a>
                  <a href="#nosotros" className="text-lg font-semibold">Nosotros</a>
                  <a href="#contacto" className="text-lg font-semibold">Contacto</a>
                  <Button className="w-full bg-blue-600">Inscribirse</Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(45%_45%_at_50%_50%,rgba(37,99,235,0.1)_0%,rgba(255,255,255,0)_100%)]" />
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="flex-1 text-center md:text-left"
            >
              <Badge variant="secondary" className="mb-4 px-3 py-1 text-blue-700 bg-blue-50 border-blue-100">
                ¡El poder de aprender!
              </Badge>
              <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight text-slate-900 mb-6 leading-tight">
                Impulsa tu carrera con <span className="text-blue-600">Cursos del Este</span>
              </h1>
              <p className="text-lg md:text-xl text-slate-600 mb-8 max-w-2xl">
                Somos tu mejor opción para capacitarte. Cursos prácticos, actualizados y con salida laboral inmediata.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
                <Button size="lg" className="bg-blue-600 hover:bg-blue-700 h-12 px-8 text-base">
                  Explorar Cursos <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
                <Button size="lg" variant="outline" className="h-12 px-8 text-base border-slate-200">
                  Saber más
                </Button>
              </div>
              <div className="mt-10 flex items-center justify-center md:justify-start gap-6 text-slate-500">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                  <span className="text-sm font-medium">Certificación Oficial</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                  <span className="text-sm font-medium">Docentes Expertos</span>
                </div>
              </div>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="flex-1 relative"
            >
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border-8 border-white">
                <img 
                  src="https://picsum.photos/seed/education/1200/800" 
                  alt="Estudiantes aprendiendo" 
                  className="w-full h-auto object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-blue-900/40 to-transparent" />
              </div>
              
              {/* Floating Cards */}
              <motion.div 
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -bottom-6 -left-6 bg-white p-4 rounded-xl shadow-lg border border-slate-100 hidden lg:block"
              >
                <div className="flex items-center gap-3">
                  <div className="bg-green-100 p-2 rounded-full">
                    <Users className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 font-medium">Estudiantes Activos</p>
                    <p className="text-lg font-bold text-slate-900">+2,500</p>
                  </div>
                </div>
              </motion.div>
              
              <motion.div 
                animate={{ y: [0, 10, 0] }}
                transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -top-6 -right-6 bg-white p-4 rounded-xl shadow-lg border border-slate-100 hidden lg:block"
              >
                <div className="flex items-center gap-3">
                  <div className="bg-yellow-100 p-2 rounded-full">
                    <Star className="w-5 h-5 text-yellow-600 fill-yellow-600" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 font-medium">Calificación Media</p>
                    <p className="text-lg font-bold text-slate-900">4.9/5.0</p>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Nuestras Áreas de Estudio</h2>
            <p className="text-slate-600 max-w-2xl mx-auto">
              Contamos con una amplia variedad de categorías diseñadas para cubrir todas tus necesidades de aprendizaje.
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {CATEGORIES.map((cat) => (
              <motion.div
                key={cat.id}
                whileHover={{ y: -5 }}
                className="group p-8 rounded-2xl border border-slate-100 bg-slate-50 hover:bg-blue-600 hover:border-blue-600 transition-all duration-300 cursor-pointer text-center"
              >
                <div className="inline-flex p-4 rounded-xl bg-white text-blue-600 group-hover:bg-blue-500 group-hover:text-white mb-4 transition-colors shadow-sm">
                  <cat.icon className="w-8 h-8" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 group-hover:text-white mb-1">{cat.name}</h3>
                <p className="text-sm text-slate-500 group-hover:text-blue-100">{cat.count} Cursos</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Courses */}
      <section id="cursos" className="py-20 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-end justify-between mb-12 gap-6">
            <div className="text-left">
              <h2 className="text-3xl font-bold text-slate-900 mb-4">Cursos Destacados</h2>
              <p className="text-slate-600 max-w-xl">
                Los programas más populares elegidos por nuestra comunidad para transformar su futuro profesional.
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" className="border-slate-200">Ver todos</Button>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {COURSES.map((course) => (
              <motion.div
                key={course.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
              >
                <Card className="overflow-hidden border-none shadow-md hover:shadow-xl transition-shadow duration-300 h-full flex flex-col">
                  <div className="relative aspect-video overflow-hidden">
                    <img 
                      src={course.image} 
                      alt={course.title} 
                      className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                      referrerPolicy="no-referrer"
                    />
                    <Badge className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm text-blue-600 hover:bg-white">
                      {course.category}
                    </Badge>
                    {course.featured && (
                      <Badge className="absolute top-4 right-4 bg-yellow-400 text-yellow-900 hover:bg-yellow-500">
                        Popular
                      </Badge>
                    )}
                  </div>
                  <CardHeader className="p-6 pb-2">
                    <div className="flex items-center gap-1 mb-2">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className={`w-3 h-3 ${i < Math.floor(course.rating) ? "text-yellow-400 fill-yellow-400" : "text-slate-300"}`} />
                      ))}
                      <span className="text-xs font-medium text-slate-500 ml-1">{course.rating}</span>
                    </div>
                    <CardTitle className="text-xl font-bold text-slate-900 line-clamp-2 leading-tight">
                      {course.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6 pt-0 flex-grow">
                    <div className="flex items-center gap-4 text-sm text-slate-500 mt-4">
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        <span>{course.duration}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="w-4 h-4" />
                        <span>Online/Presencial</span>
                      </div>
                    </div>
                  </CardContent>
                  <Separator className="bg-slate-100" />
                  <CardFooter className="p-6 flex items-center justify-between">
                    <span className="text-2xl font-bold text-blue-600">{course.price}</span>
                    <Button variant="ghost" className="text-blue-600 hover:text-blue-700 hover:bg-blue-50 p-0 h-auto font-bold group">
                      Inscribirse <ChevronRight className="ml-1 w-4 h-4 transition-transform group-hover:translate-x-1" />
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="nosotros" className="py-20 bg-white overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            <div className="flex-1 relative">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-4">
                  <img 
                    src="https://picsum.photos/seed/learn1/400/500" 
                    alt="Clase" 
                    className="rounded-2xl w-full h-64 object-cover shadow-lg"
                    referrerPolicy="no-referrer"
                  />
                  <img 
                    src="https://picsum.photos/seed/learn2/400/300" 
                    alt="Estudiante" 
                    className="rounded-2xl w-full h-48 object-cover shadow-lg"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="pt-12 space-y-4">
                  <img 
                    src="https://picsum.photos/seed/learn3/400/300" 
                    alt="Oficina" 
                    className="rounded-2xl w-full h-48 object-cover shadow-lg"
                    referrerPolicy="no-referrer"
                  />
                  <img 
                    src="https://picsum.photos/seed/learn4/400/500" 
                    alt="Taller" 
                    className="rounded-2xl w-full h-64 object-cover shadow-lg"
                    referrerPolicy="no-referrer"
                  />
                </div>
              </div>
              <div className="absolute -z-10 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-blue-50 rounded-full blur-3xl opacity-50" />
            </div>
            
            <div className="flex-1">
              <Badge className="mb-4 bg-blue-100 text-blue-700 hover:bg-blue-100 border-none">Sobre Nosotros</Badge>
              <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6 leading-tight">
                Más de 15 años formando profesionales en la región
              </h2>
              <p className="text-slate-600 mb-6 text-lg">
                Cursos del Este nació con la misión de democratizar el acceso a la educación técnica y profesional de calidad. Creemos en el aprendizaje práctico y orientado al mercado laboral actual.
              </p>
              
              <div className="space-y-4 mb-8">
                {[
                  "Metodología 100% práctica y dinámica",
                  "Bolsa de trabajo exclusiva para egresados",
                  "Flexibilidad horaria y modalidades híbridas",
                  "Infraestructura moderna y equipamiento de punta"
                ].map((item, i) => (
                  <div key={i} className="flex items-start gap-3">
                    <div className="mt-1 bg-blue-600 rounded-full p-1">
                      <CheckCircle2 className="w-3 h-3 text-white" />
                    </div>
                    <span className="font-medium text-slate-700">{item}</span>
                  </div>
                ))}
              </div>
              
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700">Conoce nuestra historia</Button>
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter / CTA */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="bg-blue-600 rounded-3xl p-8 md:p-16 text-center text-white relative overflow-hidden shadow-2xl">
            <div className="absolute top-0 left-0 w-full h-full opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]" />
            <div className="relative z-10 max-w-3xl mx-auto">
              <h2 className="text-3xl md:text-5xl font-bold mb-6">¿Listo para empezar tu camino?</h2>
              <p className="text-blue-100 text-lg mb-10">
                Suscríbete para recibir novedades sobre nuevos cursos, becas y descuentos exclusivos directamente en tu correo.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto">
                <Input 
                  placeholder="Tu correo electrónico" 
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/60 h-12 focus-visible:ring-white"
                />
                <Button size="lg" className="bg-white text-blue-600 hover:bg-blue-50 h-12 px-8 font-bold">
                  Suscribirme
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer id="contacto" className="bg-slate-900 text-slate-300 pt-20 pb-10">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
            <div className="space-y-6">
              <div className="flex items-center gap-2">
                <div className="bg-blue-600 p-2 rounded-lg">
                  <GraduationCap className="text-white w-6 h-6" />
                </div>
                <span className="text-xl font-bold tracking-tight text-white">Cursos del Este</span>
              </div>
              <p className="text-slate-400 leading-relaxed">
                Líderes en capacitación profesional con miles de egresados que hoy triunfan en sus respectivos campos.
              </p>
              <div className="flex gap-4">
                <a href="#" className="p-2 rounded-full bg-slate-800 hover:bg-blue-600 transition-colors">
                  <Facebook className="w-5 h-5" />
                </a>
                <a href="#" className="p-2 rounded-full bg-slate-800 hover:bg-blue-600 transition-colors">
                  <Instagram className="w-5 h-5" />
                </a>
                <a href="#" className="p-2 rounded-full bg-slate-800 hover:bg-blue-600 transition-colors">
                  <Twitter className="w-5 h-5" />
                </a>
              </div>
            </div>
            
            <div>
              <h3 className="text-white font-bold text-lg mb-6">Enlaces Rápidos</h3>
              <ul className="space-y-4">
                <li><a href="#" className="hover:text-blue-400 transition-colors">Inicio</a></li>
                <li><a href="#cursos" className="hover:text-blue-400 transition-colors">Todos los Cursos</a></li>
                <li><a href="#nosotros" className="hover:text-blue-400 transition-colors">Sobre Nosotros</a></li>
                <li><a href="#" className="hover:text-blue-400 transition-colors">Preguntas Frecuentes</a></li>
                <li><a href="#" className="hover:text-blue-400 transition-colors">Blog de Noticias</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-white font-bold text-lg mb-6">Cursos Populares</h3>
              <ul className="space-y-4">
                <li><a href="#" className="hover:text-blue-400 transition-colors">Excel Avanzado</a></li>
                <li><a href="#" className="hover:text-blue-400 transition-colors">Inglés Nivel 1</a></li>
                <li><a href="#" className="hover:text-blue-400 transition-colors">Marketing Digital</a></li>
                <li><a href="#" className="hover:text-blue-400 transition-colors">Diseño Web</a></li>
                <li><a href="#" className="hover:text-blue-400 transition-colors">Reparación de PC</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-white font-bold text-lg mb-6">Contacto</h3>
              <ul className="space-y-4">
                <li className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-blue-500 shrink-0" />
                  <span>Av. Principal 123, Maldonado, Uruguay</span>
                </li>
                <li className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-blue-500 shrink-0" />
                  <span>+598 42XX XXXX</span>
                </li>
                <li className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-blue-500 shrink-0" />
                  <span>info@cursosdeleste.com</span>
                </li>
              </ul>
            </div>
          </div>
          
          <Separator className="bg-slate-800 mb-8" />
          
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-slate-500">
            <p>© 2026 Cursos del Este. Todos los derechos reservados.</p>
            <div className="flex gap-6">
              <a href="#" className="hover:text-slate-300 transition-colors">Privacidad</a>
              <a href="#" className="hover:text-slate-300 transition-colors">Términos</a>
              <a href="#" className="hover:text-slate-300 transition-colors">Cookies</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
